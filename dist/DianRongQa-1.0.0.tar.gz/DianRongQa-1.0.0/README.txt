该包是成都团队使用的一个公用基础测试包．
主要功能：
１．支持web测试
２．支持接口测试


查看包文件：
python setup.py check
打包命令：
python setup.py sdist
安装包：
sudo pip install DianRongQa-1.0.0.tar.gz